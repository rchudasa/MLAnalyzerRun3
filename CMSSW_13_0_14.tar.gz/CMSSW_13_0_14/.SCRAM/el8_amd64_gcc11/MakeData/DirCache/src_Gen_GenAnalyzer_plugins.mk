ifeq ($(strip $(GenGenAnalyzerAuto)),)
GenGenAnalyzerAuto := self/src/Gen/GenAnalyzer/plugins
PLUGINS:=yes
GenGenAnalyzerAuto_files := $(patsubst src/Gen/GenAnalyzer/plugins/%,%,$(wildcard $(foreach dir,src/Gen/GenAnalyzer/plugins ,$(foreach ext,$(SRC_FILES_SUFFIXES),$(dir)/*.$(ext)))))
GenGenAnalyzerAuto_BuildFile    := $(WORKINGDIR)/cache/bf/src/Gen/GenAnalyzer/plugins/BuildFile
GenGenAnalyzerAuto_LOC_USE := self   FWCore/Framework FWCore/PluginManager FWCore/ParameterSet DataFormats/TrackReco root SimDataFormats/GeneratorProducts DataFormats/PatCandidates GeneratorInterface/Core CommonTools/UtilAlgos 
GenGenAnalyzerAuto_PRE_INIT_FUNC += $$(eval $$(call edmPlugin,GenGenAnalyzerAuto,GenGenAnalyzerAuto,$(SCRAMSTORENAME_LIB),src/Gen/GenAnalyzer/plugins))
GenGenAnalyzerAuto_PACKAGE := self/src/Gen/GenAnalyzer/plugins
ALL_PRODS += GenGenAnalyzerAuto
Gen/GenAnalyzer_forbigobj+=GenGenAnalyzerAuto
GenGenAnalyzerAuto_INIT_FUNC        += $$(eval $$(call Library,GenGenAnalyzerAuto,src/Gen/GenAnalyzer/plugins,src_Gen_GenAnalyzer_plugins,$(SCRAMSTORENAME_BIN),,$(SCRAMSTORENAME_LIB),$(SCRAMSTORENAME_LOGS),edm))
GenGenAnalyzerAuto_CLASS := LIBRARY
else
$(eval $(call MultipleWarningMsg,GenGenAnalyzerAuto,src/Gen/GenAnalyzer/plugins))
endif
ALL_COMMONRULES += src_Gen_GenAnalyzer_plugins
src_Gen_GenAnalyzer_plugins_parent := Gen/GenAnalyzer
src_Gen_GenAnalyzer_plugins_INIT_FUNC += $$(eval $$(call CommonProductRules,src_Gen_GenAnalyzer_plugins,src/Gen/GenAnalyzer/plugins,PLUGINS))
