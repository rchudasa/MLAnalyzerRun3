ifeq ($(strip $(MLAnalyzerRun3RecHitAnalyzerAuto)),)
MLAnalyzerRun3RecHitAnalyzerAuto := self/src/MLAnalyzerRun3/RecHitAnalyzer/plugins
PLUGINS:=yes
MLAnalyzerRun3RecHitAnalyzerAuto_files := $(patsubst src/MLAnalyzerRun3/RecHitAnalyzer/plugins/%,%,$(wildcard $(foreach dir,src/MLAnalyzerRun3/RecHitAnalyzer/plugins ,$(foreach ext,$(SRC_FILES_SUFFIXES),$(dir)/*.$(ext)))))
MLAnalyzerRun3RecHitAnalyzerAuto_BuildFile    := $(WORKINGDIR)/cache/bf/src/MLAnalyzerRun3/RecHitAnalyzer/plugins/BuildFile
MLAnalyzerRun3RecHitAnalyzerAuto_LOC_USE := self   FWCore/Framework FWCore/PluginManager FWCore/ParameterSet FWCore/Common DataFormats/HLTReco HLTrigger/HLTcore DataFormats/TrackReco DataFormats/TrackingRecHit DataFormats/SiStripCluster DataFormats/SiStripDetId DataFormats/TrackerCommon DataFormats/EcalRecHit DataFormats/HcalDetId DataFormats/HcalRecHit DataFormats/ParticleFlowCandidate DataFormats/PatCandidates DataFormats/EgammaCandidates DataFormats/EgammaReco DataFormats/Common DataFormats/METReco SimDataFormats/GeneratorProducts DQM/HcalCommon Geometry/CaloGeometry Geometry/Records Geometry/CommonTopologies CommonTools/UtilAlgos Calibration/IsolatedParticles TauAnalysis/ClassicSVfit TauAnalysis/SVfitTF RecoMET/METAlgorithms RecoMET/METProducers JetMETCorrections/Modules RecoLocalTracker/Phase2TrackerRecHits MagneticField/Engine MagneticField/Records TrackingTools/Records TrackingTools/TransientTrack TrackingTools/TrajectoryState 
MLAnalyzerRun3RecHitAnalyzerAuto_PRE_INIT_FUNC += $$(eval $$(call edmPlugin,MLAnalyzerRun3RecHitAnalyzerAuto,MLAnalyzerRun3RecHitAnalyzerAuto,$(SCRAMSTORENAME_LIB),src/MLAnalyzerRun3/RecHitAnalyzer/plugins))
MLAnalyzerRun3RecHitAnalyzerAuto_PACKAGE := self/src/MLAnalyzerRun3/RecHitAnalyzer/plugins
ALL_PRODS += MLAnalyzerRun3RecHitAnalyzerAuto
MLAnalyzerRun3/RecHitAnalyzer_forbigobj+=MLAnalyzerRun3RecHitAnalyzerAuto
MLAnalyzerRun3RecHitAnalyzerAuto_INIT_FUNC        += $$(eval $$(call Library,MLAnalyzerRun3RecHitAnalyzerAuto,src/MLAnalyzerRun3/RecHitAnalyzer/plugins,src_MLAnalyzerRun3_RecHitAnalyzer_plugins,$(SCRAMSTORENAME_BIN),,$(SCRAMSTORENAME_LIB),$(SCRAMSTORENAME_LOGS),edm))
MLAnalyzerRun3RecHitAnalyzerAuto_CLASS := LIBRARY
else
$(eval $(call MultipleWarningMsg,MLAnalyzerRun3RecHitAnalyzerAuto,src/MLAnalyzerRun3/RecHitAnalyzer/plugins))
endif
ALL_COMMONRULES += src_MLAnalyzerRun3_RecHitAnalyzer_plugins
src_MLAnalyzerRun3_RecHitAnalyzer_plugins_parent := MLAnalyzerRun3/RecHitAnalyzer
src_MLAnalyzerRun3_RecHitAnalyzer_plugins_INIT_FUNC += $$(eval $$(call CommonProductRules,src_MLAnalyzerRun3_RecHitAnalyzer_plugins,src/MLAnalyzerRun3/RecHitAnalyzer/plugins,PLUGINS))
