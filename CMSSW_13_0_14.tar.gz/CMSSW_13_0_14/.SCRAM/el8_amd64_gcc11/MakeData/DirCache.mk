ifeq ($(strip $(TauAnalysis/ClassicSVfit)),)
ALL_COMMONRULES += src_TauAnalysis_ClassicSVfit_src
src_TauAnalysis_ClassicSVfit_src_parent := TauAnalysis/ClassicSVfit
src_TauAnalysis_ClassicSVfit_src_INIT_FUNC := $$(eval $$(call CommonProductRules,src_TauAnalysis_ClassicSVfit_src,src/TauAnalysis/ClassicSVfit/src,LIBRARY))
TauAnalysisClassicSVfit := self/TauAnalysis/ClassicSVfit
TauAnalysis/ClassicSVfit := TauAnalysisClassicSVfit
TauAnalysisClassicSVfit_files := $(patsubst src/TauAnalysis/ClassicSVfit/src/%,%,$(wildcard $(foreach dir,src/TauAnalysis/ClassicSVfit/src ,$(foreach ext,$(SRC_FILES_SUFFIXES),$(dir)/*.$(ext)))))
TauAnalysisClassicSVfit_BuildFile    := $(WORKINGDIR)/cache/bf/src/TauAnalysis/ClassicSVfit/BuildFile
TauAnalysisClassicSVfit_LOC_FLAGS_CPPDEFINES   := -DUSE_SVFITTF
TauAnalysisClassicSVfit_LOC_FLAGS_LDFLAGS   := -rdynamic
TauAnalysisClassicSVfit_LOC_USE := self   TauAnalysis/SVfitTF boost root roofit 
TauAnalysisClassicSVfit_EX_LIB   := TauAnalysisClassicSVfit
TauAnalysisClassicSVfit_EX_USE   := $(foreach d,$(TauAnalysisClassicSVfit_LOC_USE),$(if $($(d)_EX_FLAGS_NO_RECURSIVE_EXPORT),,$d))
TauAnalysisClassicSVfit_PACKAGE := self/src/TauAnalysis/ClassicSVfit/src
ALL_PRODS += TauAnalysisClassicSVfit
TauAnalysisClassicSVfit_CLASS := LIBRARY
TauAnalysis/ClassicSVfit_forbigobj+=TauAnalysisClassicSVfit
TauAnalysisClassicSVfit_INIT_FUNC        += $$(eval $$(call Library,TauAnalysisClassicSVfit,src/TauAnalysis/ClassicSVfit/src,src_TauAnalysis_ClassicSVfit_src,$(SCRAMSTORENAME_BIN),,$(SCRAMSTORENAME_LIB),$(SCRAMSTORENAME_LOGS),))
endif
ifeq ($(strip $(TauAnalysis/SVfitTF)),)
ALL_COMMONRULES += src_TauAnalysis_SVfitTF_src
src_TauAnalysis_SVfitTF_src_parent := TauAnalysis/SVfitTF
src_TauAnalysis_SVfitTF_src_INIT_FUNC := $$(eval $$(call CommonProductRules,src_TauAnalysis_SVfitTF_src,src/TauAnalysis/SVfitTF/src,LIBRARY))
TauAnalysisSVfitTF := self/TauAnalysis/SVfitTF
TauAnalysis/SVfitTF := TauAnalysisSVfitTF
TauAnalysisSVfitTF_files := $(patsubst src/TauAnalysis/SVfitTF/src/%,%,$(wildcard $(foreach dir,src/TauAnalysis/SVfitTF/src ,$(foreach ext,$(SRC_FILES_SUFFIXES),$(dir)/*.$(ext)))))
TauAnalysisSVfitTF_BuildFile    := $(WORKINGDIR)/cache/bf/src/TauAnalysis/SVfitTF/BuildFile
TauAnalysisSVfitTF_LOC_FLAGS_LDFLAGS   := -rdynamic
TauAnalysisSVfitTF_LOC_USE := self   CondFormats/JetMETObjects DataFormats/TauReco FWCore/ParameterSet root roofit 
TauAnalysisSVfitTF_EX_LIB   := TauAnalysisSVfitTF
TauAnalysisSVfitTF_EX_USE   := $(foreach d,$(TauAnalysisSVfitTF_LOC_USE),$(if $($(d)_EX_FLAGS_NO_RECURSIVE_EXPORT),,$d))
TauAnalysisSVfitTF_PACKAGE := self/src/TauAnalysis/SVfitTF/src
ALL_PRODS += TauAnalysisSVfitTF
TauAnalysisSVfitTF_CLASS := LIBRARY
TauAnalysis/SVfitTF_forbigobj+=TauAnalysisSVfitTF
TauAnalysisSVfitTF_INIT_FUNC        += $$(eval $$(call Library,TauAnalysisSVfitTF,src/TauAnalysis/SVfitTF/src,src_TauAnalysis_SVfitTF_src,$(SCRAMSTORENAME_BIN),,$(SCRAMSTORENAME_LIB),$(SCRAMSTORENAME_LOGS),))
endif
ifeq ($(strip $(GenGenAnalyzerAuto)),)
GenGenAnalyzerAuto := self/src/Gen/GenAnalyzer/plugins
PLUGINS:=yes
GenGenAnalyzerAuto_files := $(patsubst src/Gen/GenAnalyzer/plugins/%,%,$(wildcard $(foreach dir,src/Gen/GenAnalyzer/plugins ,$(foreach ext,$(SRC_FILES_SUFFIXES),$(dir)/*.$(ext)))))
GenGenAnalyzerAuto_BuildFile    := $(WORKINGDIR)/cache/bf/src/Gen/GenAnalyzer/plugins/BuildFile
GenGenAnalyzerAuto_LOC_USE := self   FWCore/Framework FWCore/PluginManager FWCore/ParameterSet DataFormats/TrackReco root SimDataFormats/GeneratorProducts DataFormats/PatCandidates GeneratorInterface/Core CommonTools/UtilAlgos 
GenGenAnalyzerAuto_PRE_INIT_FUNC += $$(eval $$(call edmPlugin,GenGenAnalyzerAuto,GenGenAnalyzerAuto,$(SCRAMSTORENAME_LIB),src/Gen/GenAnalyzer/plugins))
GenGenAnalyzerAuto_PACKAGE := self/src/Gen/GenAnalyzer/plugins
ALL_PRODS += GenGenAnalyzerAuto
Gen/GenAnalyzer_forbigobj+=GenGenAnalyzerAuto
GenGenAnalyzerAuto_INIT_FUNC        += $$(eval $$(call Library,GenGenAnalyzerAuto,src/Gen/GenAnalyzer/plugins,src_Gen_GenAnalyzer_plugins,$(SCRAMSTORENAME_BIN),,$(SCRAMSTORENAME_LIB),$(SCRAMSTORENAME_LOGS),edm))
GenGenAnalyzerAuto_CLASS := LIBRARY
else
$(eval $(call MultipleWarningMsg,GenGenAnalyzerAuto,src/Gen/GenAnalyzer/plugins))
endif
ALL_COMMONRULES += src_Gen_GenAnalyzer_plugins
src_Gen_GenAnalyzer_plugins_parent := Gen/GenAnalyzer
src_Gen_GenAnalyzer_plugins_INIT_FUNC += $$(eval $$(call CommonProductRules,src_Gen_GenAnalyzer_plugins,src/Gen/GenAnalyzer/plugins,PLUGINS))
ifeq ($(strip $(MLAnalyzerRun3RecHitAnalyzerAuto)),)
MLAnalyzerRun3RecHitAnalyzerAuto := self/src/MLAnalyzerRun3/RecHitAnalyzer/plugins
PLUGINS:=yes
MLAnalyzerRun3RecHitAnalyzerAuto_files := $(patsubst src/MLAnalyzerRun3/RecHitAnalyzer/plugins/%,%,$(wildcard $(foreach dir,src/MLAnalyzerRun3/RecHitAnalyzer/plugins ,$(foreach ext,$(SRC_FILES_SUFFIXES),$(dir)/*.$(ext)))))
MLAnalyzerRun3RecHitAnalyzerAuto_BuildFile    := $(WORKINGDIR)/cache/bf/src/MLAnalyzerRun3/RecHitAnalyzer/plugins/BuildFile
MLAnalyzerRun3RecHitAnalyzerAuto_LOC_USE := self   FWCore/Framework FWCore/PluginManager FWCore/ParameterSet FWCore/Common DataFormats/HLTReco HLTrigger/HLTcore DataFormats/TrackReco DataFormats/TrackingRecHit DataFormats/SiStripCluster DataFormats/SiStripDetId DataFormats/TrackerCommon DataFormats/EcalRecHit DataFormats/HcalDetId DataFormats/HcalRecHit DataFormats/ParticleFlowCandidate DataFormats/PatCandidates DataFormats/EgammaCandidates DataFormats/EgammaReco DataFormats/Common DataFormats/METReco SimDataFormats/GeneratorProducts DQM/HcalCommon Geometry/CaloGeometry Geometry/Records Geometry/CommonTopologies CommonTools/UtilAlgos Calibration/IsolatedParticles TauAnalysis/ClassicSVfit TauAnalysis/SVfitTF RecoMET/METAlgorithms RecoMET/METProducers JetMETCorrections/Modules RecoLocalTracker/Phase2TrackerRecHits MagneticField/Engine MagneticField/Records TrackingTools/Records TrackingTools/TransientTrack TrackingTools/TrajectoryState 
MLAnalyzerRun3RecHitAnalyzerAuto_PRE_INIT_FUNC += $$(eval $$(call edmPlugin,MLAnalyzerRun3RecHitAnalyzerAuto,MLAnalyzerRun3RecHitAnalyzerAuto,$(SCRAMSTORENAME_LIB),src/MLAnalyzerRun3/RecHitAnalyzer/plugins))
MLAnalyzerRun3RecHitAnalyzerAuto_PACKAGE := self/src/MLAnalyzerRun3/RecHitAnalyzer/plugins
ALL_PRODS += MLAnalyzerRun3RecHitAnalyzerAuto
MLAnalyzerRun3/RecHitAnalyzer_forbigobj+=MLAnalyzerRun3RecHitAnalyzerAuto
MLAnalyzerRun3RecHitAnalyzerAuto_INIT_FUNC        += $$(eval $$(call Library,MLAnalyzerRun3RecHitAnalyzerAuto,src/MLAnalyzerRun3/RecHitAnalyzer/plugins,src_MLAnalyzerRun3_RecHitAnalyzer_plugins,$(SCRAMSTORENAME_BIN),,$(SCRAMSTORENAME_LIB),$(SCRAMSTORENAME_LOGS),edm))
MLAnalyzerRun3RecHitAnalyzerAuto_CLASS := LIBRARY
else
$(eval $(call MultipleWarningMsg,MLAnalyzerRun3RecHitAnalyzerAuto,src/MLAnalyzerRun3/RecHitAnalyzer/plugins))
endif
ALL_COMMONRULES += src_MLAnalyzerRun3_RecHitAnalyzer_plugins
src_MLAnalyzerRun3_RecHitAnalyzer_plugins_parent := MLAnalyzerRun3/RecHitAnalyzer
src_MLAnalyzerRun3_RecHitAnalyzer_plugins_INIT_FUNC += $$(eval $$(call CommonProductRules,src_MLAnalyzerRun3_RecHitAnalyzer_plugins,src/MLAnalyzerRun3/RecHitAnalyzer/plugins,PLUGINS))
